// for (i=0;i<=10;i++){

// 	console.log(i);
// }
// k=Number(prompt('k soni'));
// n=Number(prompt('n soni'));

// for (let i=1;i<=n;i++){
// 	console.log(k);
// }
let a=Number(prompt('a soni'));
let b=Number(prompt('b soni'));
let count=0;
if(a<b){
	for(let i=a;i<=b;i++){
		count++;
		console.log(i);
	} 
}else{
console.log('a soni doim b sonidan kichik nolishi kerak');
	}
console.log(count );
